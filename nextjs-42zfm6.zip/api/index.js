// create mocked service for creating users based on Promise
export const createUser = async (payload) => {
  return {};
};
